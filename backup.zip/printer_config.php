<?php
// printer_config.php
// Exemplo de configuração. Edite conforme seu ambiente.
// tipo: "network" (recomendado) ou "windows"

$printer_config = [
    'tipo' => 'network', // 'network' ou 'windows'

    // Network (impressora com IP fixo)
    'ip' => '192.168.0.200',
    'port' => 9100,

    // Windows (impressora compartilhada via Windows)
    // 'share_name' => '\\NOME_DO_PC\\NOME_COMPARTILHAMENTO',
    // Exemplo: '\\CAIXA-PC\\EPSON_TERMICA'

    // Layout
    'nome_restaurante' => 'Meu Bar e Restaurante',
    'paper' => 80, // 80 ou 58 (ajuste apenas colunas/formatacao)
];
