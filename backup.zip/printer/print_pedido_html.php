<?php
// printer/print_pedido_html.php
require_once __DIR__ . '/../funcoes.php';

function gerarCupomHtml(int $pedidoId): array {
    $pedido = getPedido($pedidoId);
    if (!$pedido) return ['success' => false, 'message' => 'Pedido não encontrado.'];

    $itens = getItensPedido($pedidoId);

    $nomeRest = "Meu Bar e Restaurante";
    $dataHora = date('d/m/Y H:i');
    $mesa = htmlspecialchars($pedido['mesa']);

    ob_start();
    ?>
    <!doctype html>
    <html lang="pt-br">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Cupom Pedido #<?= (int)$pedidoId ?></title>
      <style>
        /* Estilo "térmico" */
        body { font-family: "Courier New", monospace; margin: 0; padding: 0; }
        .cupom { width: 80mm; padding: 6mm; }
        .center { text-align: center; }
        .hr { border-top: 1px dashed #000; margin: 6px 0; }
        .row { display: flex; justify-content: space-between; gap: 8px; }
        .small { font-size: 12px; }
        .bold { font-weight: 700; }
        @media print {
          body { margin: 0; }
          .no-print { display: none; }
        }
      </style>
    </head>
    <body>
      <div class="cupom">
        <div class="center bold"><?= htmlspecialchars($nomeRest) ?></div>
        <div class="center small"><?= $dataHora ?></div>
        <div class="center bold">MESA: <?= $mesa ?></div>
        <div class="hr"></div>

        <?php foreach ($itens as $it): ?>
          <?php
            $qtd = (int)$it['quantidade'];
            $nome = (string)$it['nome'];
            $sub = number_format((float)$it['subtotal'], 2, ',', '.');
          ?>
          <div class="row">
            <div><?= $qtd ?>x <?= htmlspecialchars($nome) ?></div>
            <div><?= $sub ?></div>
          </div>
        <?php endforeach; ?>

        <div class="hr"></div>
        <div class="row bold">
          <div>TOTAL</div>
          <div>R$ <?= number_format((float)$pedido['total'], 2, ',', '.') ?></div>
        </div>

        <div class="hr"></div>
        <div class="center small">Pedido #<?= (int)$pedidoId ?></div>

        <div class="no-print" style="margin-top:10px;">
          <button onclick="window.print()">Imprimir / Salvar em PDF</button>
        </div>
      </div>

      <script>
        // Se quiser auto-abrir o print, descomente:
        // window.onload = () => setTimeout(() => window.print(), 300);
      </script>
    </body>
    </html>
    <?php
    $html = ob_get_clean();

    return ['success' => true, 'html' => $html];
}
