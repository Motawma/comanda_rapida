<?php
// printer/print_pedido.php
// Função imprimirPedido($pedidoId, $printerConfig)
// Requer a biblioteca mike42/escpos-php instalada via Composer
//
// Instalação (na pasta do projeto):
//   composer require mike42/escpos-php
//
// Isso cria vendor/autoload.php

require_once __DIR__ . '/../funcoes.php';

function imprimirPedido(int $pedidoId, array $printerConfig): array {
    $pedido = getPedido($pedidoId);
    if (!$pedido) return ['success' => false, 'message' => 'Pedido não encontrado.'];
    $itens = getItensPedido($pedidoId);

    $nomeRest = $printerConfig['nome_restaurante'] ?? 'RESTAURANTE';
    $dataHora = date('d/m/Y H:i');
    $cols = 32; // simples para 80mm; para 58mm você pode reduzir (ex: 24)

    // Carregar autoload do Composer
    $autoload = __DIR__ . '/../vendor/autoload.php';
    if (!file_exists($autoload)) {
        return ['success' => false, 'message' => 'Dependência não instalada. Rode: composer require mike42/escpos-php'];
    }
    require_once $autoload;

    try {
        // Classes (fully-qualified para evitar problemas com "use" dentro de função)
        $Printer = 'Mike42\\Escpos\\Printer';
        $NetworkPrintConnector = 'Mike42\\Escpos\\PrintConnectors\\NetworkPrintConnector';
        $WindowsPrintConnector = 'Mike42\\Escpos\\PrintConnectors\\WindowsPrintConnector';

        $connector = null;

        if (($printerConfig['tipo'] ?? 'network') === 'network') {
            $ip = (string)($printerConfig['ip'] ?? '');
            $port = (int)($printerConfig['port'] ?? 9100);
            if ($ip === '') return ['success' => false, 'message' => 'Configuração de rede: IP não informado.'];
            $connector = new $NetworkPrintConnector($ip, $port, 6, 200);
        } else {
            $share = (string)($printerConfig['share_name'] ?? '');
            if ($share === '') return ['success' => false, 'message' => 'Configuração Windows: share_name não informado.'];
            $connector = new $WindowsPrintConnector($share);
        }

        $printer = new $Printer($connector);

        // Cabeçalho
        $printer->setJustification($Printer::JUSTIFY_CENTER);
        $printer->text($nomeRest . "\n");
        $printer->text($dataHora . "\n");
        $printer->text("Mesa: " . $pedido['mesa'] . "\n");
        $printer->text(str_repeat('-', $cols) . "\n");
        $printer->setJustification($Printer::JUSTIFY_LEFT);

        // Itens
        foreach ($itens as $it) {
            $qtd = (int)$it['quantidade'];
            $nome = (string)$it['nome'];
            $subtotal = number_format((float)$it['subtotal'], 2, ',', '.');

            $line = $qtd . " x " . $nome;
            // Espaço simples para alinhar subtotal à direita
            $spaces = $cols - mb_strlen($line) - mb_strlen($subtotal);
            if ($spaces < 1) $spaces = 1;

            $printer->text($line . str_repeat(' ', $spaces) . $subtotal . "\n");
        }

        $printer->text(str_repeat('-', $cols) . "\n");
        $printer->setEmphasis(true);
        $totalFmt = number_format((float)$pedido['total'], 2, ',', '.');
        $printer->text("TOTAL: R$ " . $totalFmt . "\n");
        $printer->setEmphasis(false);

        $printer->text("\n\n");
        // Corte de papel (se suportado)
        try { $printer->cut(); } catch (Throwable $e) {}

        $printer->close();

        return ['success' => true];
    } catch (Throwable $e) {
        return ['success' => false, 'message' => $e->getMessage()];
    }
}
