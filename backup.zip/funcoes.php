<?php
// funcoes.php
require_once __DIR__ . '/conexao.php';

// Cria pedido e itens; retorna ID do pedido (int) ou array ['error'=>true,'message'=>...]
function criarPedidoNoBanco(string $mesa, array $itens) {
    $pdo = getPDO();

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("INSERT INTO pedidos (mesa, status, total, impresso) VALUES (?, 'PENDENTE', 0.00, 0)");
        $stmt->execute([$mesa]);
        $pedidoId = (int)$pdo->lastInsertId();

        $insertItem = $pdo->prepare("
            INSERT INTO itens_pedido (pedido_id, produto_id, quantidade, preco_unit, subtotal)
            VALUES (?, ?, ?, ?, ?)
        ");

        $getPreco = $pdo->prepare("SELECT preco FROM produtos WHERE id = ? AND ativo = 1");

        foreach ($itens as $item) {
            $produtoId = (int)($item['produto_id'] ?? 0);
            $quantidade = max(1, (int)($item['quantidade'] ?? 1));

            if ($produtoId <= 0) {
                throw new Exception("Produto inválido.");
            }

            $getPreco->execute([$produtoId]);
            $prod = $getPreco->fetch();
            if (!$prod) {
                throw new Exception("Produto ID {$produtoId} não encontrado ou inativo.");
            }

            $preco = (float)$prod['preco'];
            $subtotal = round($preco * $quantidade, 2);

            $insertItem->execute([$pedidoId, $produtoId, $quantidade, $preco, $subtotal]);
        }

        $total = calcularTotal($pdo, $pedidoId);
        $u = $pdo->prepare("UPDATE pedidos SET total = ? WHERE id = ?");
        $u->execute([$total, $pedidoId]);

        $pdo->commit();
        return $pedidoId;
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        return ['error' => true, 'message' => $e->getMessage()];
    }
}

function calcularTotal($pdoOrId, ?int $pedidoIdOptional = null): float {
    if ($pdoOrId instanceof PDO) {
        $pdo = $pdoOrId;
        $pedidoId = $pedidoIdOptional;
    } else {
        $pdo = getPDO();
        $pedidoId = (int)$pdoOrId;
    }

    $stmt = $pdo->prepare("SELECT COALESCE(SUM(subtotal),0) AS total FROM itens_pedido WHERE pedido_id = ?");
    $stmt->execute([$pedidoId]);
    $r = $stmt->fetch();
    return (float)($r['total'] ?? 0.0);
}

function marcarImpresso(int $pedidoId): bool {
    $pdo = getPDO();
    $stmt = $pdo->prepare("UPDATE pedidos SET impresso = 1 WHERE id = ?");
    return (bool)$stmt->execute([$pedidoId]);
}

function getProdutoList(): array {
    $pdo = getPDO();
    $stmt = $pdo->query("SELECT id, nome, preco, categoria FROM produtos WHERE ativo = 1 ORDER BY categoria, nome");
    return $stmt->fetchAll();
}

function getPedido(int $pedidoId): ?array {
    $pdo = getPDO();
    $stmt = $pdo->prepare("SELECT * FROM pedidos WHERE id = ?");
    $stmt->execute([$pedidoId]);
    $r = $stmt->fetch();
    return $r ?: null;
}

function getItensPedido(int $pedidoId): array {
    $pdo = getPDO();
    $stmt = $pdo->prepare("
        SELECT ip.*, p.nome
        FROM itens_pedido ip
        LEFT JOIN produtos p ON p.id = ip.produto_id
        WHERE ip.pedido_id = ?
        ORDER BY ip.id ASC
    ");
    $stmt->execute([$pedidoId]);
    return $stmt->fetchAll();
}
