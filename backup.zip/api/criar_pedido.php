<?php
// api/criar_pedido.php
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../funcoes.php';
require_once __DIR__ . '/../printer_config.php';

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['success' => false, 'message' => 'JSON inválido.']);
    exit;
}

$mesa = trim((string)($input['mesa'] ?? ''));
$itens = $input['items'] ?? [];

if ($mesa === '' || !is_array($itens) || count($itens) === 0) {
    echo json_encode(['success' => false, 'message' => 'Mesa e itens são obrigatórios.']);
    exit;
}

// Criar pedido no banco
$result = criarPedidoNoBanco($mesa, $itens);
if (is_array($result) && ($result['error'] ?? false)) {
    echo json_encode(['success' => false, 'message' => $result['message'] ?? 'Erro ao criar pedido.']);
    exit;
}
$pedidoId = (int)$result;

// Se a lib ESC/POS (composer) existir -> imprime direto
$autoload = __DIR__ . '/../vendor/autoload.php';

if (file_exists($autoload)) {
    require_once __DIR__ . '/../printer/print_pedido.php';

    try {
        $printResult = imprimirPedido($pedidoId, $printer_config);
        if (!empty($printResult['success'])) {
            marcarImpresso($pedidoId);
            echo json_encode(['success' => true, 'pedido_id' => $pedidoId, 'message' => 'Impressão OK']);
        } else {
            echo json_encode([
                'success' => false,
                'pedido_id' => $pedidoId,
                'message' => 'Falha na impressão: ' . ($printResult['message'] ?? 'desconhecida')
            ]);
        }
    } catch (Throwable $e) {
        echo json_encode([
            'success' => false,
            'pedido_id' => $pedidoId,
            'message' => 'Exceção ao imprimir: ' . $e->getMessage()
        ]);
    }
    exit;
}

// Sem lib -> modo PDF/HTML (gera cupom e abre para imprimir/salvar em PDF)
require_once __DIR__ . '/../printer/print_pedido_html.php';

$cupom = gerarCupomHtml($pedidoId);
if (!empty($cupom['success'])) {
    // Não marcamos como impresso aqui (é teste em PDF).
    // Se quiser marcar mesmo assim, descomente:
    // marcarImpresso($pedidoId);

    echo json_encode([
        'success' => true,
        'pedido_id' => $pedidoId,
        'message' => 'Pedido salvo. Abra o cupom para imprimir/salvar em PDF.',
        // Use caminho relativo a partir do index.php (raiz do projeto)
        'cupom_url' => 'printer/cupom.php?pedido_id=' . $pedidoId
    ]);
} else {
    echo json_encode([
        'success' => false,
        'pedido_id' => $pedidoId,
        'message' => $cupom['message'] ?? 'Erro ao gerar cupom'
    ]);
}
